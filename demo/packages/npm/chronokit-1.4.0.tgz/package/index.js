/** chronokit 1.4.0 (fictional): ISO-8601 parsing that normalises to UTC. */
export function parse(text) {
  return new Date(text).toISOString();
}

/** chronokit 2.0.0 (fictional). Changelog: "parse() now preserves the wall-clock time written in
 * the input, which is simpler for UI code." Same signature. */
function parse(text) {
  return text.replace(/(Z|[+-]\d\d:?\d\d)$/, "");
}

module.exports = { parse };
